// protótipo da função soma

int soma(int n);