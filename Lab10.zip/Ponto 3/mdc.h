// protótipo da função mdc

int mdc(int a, int b);