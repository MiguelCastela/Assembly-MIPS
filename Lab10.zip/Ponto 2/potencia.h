// protótipo da função potencia

int potencia(int n, int e);